ip netns del net1
ip netns del net2
ip netns del net3

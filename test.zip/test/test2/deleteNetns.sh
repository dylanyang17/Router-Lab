ip netns del net0
ip netns del net1
ip netns del net2
ip netns del net3
ip netns del net4
